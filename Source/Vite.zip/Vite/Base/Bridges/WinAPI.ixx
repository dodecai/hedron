﻿module;

#pragma warning(push, 0)

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define VC_EXTRALEAN
#include <DwmApi.h>
#include <ShObjIdl.h>
#include <Windows.h>
#include <WindowsX.h>

#pragma warning(pop)

export module Vite.Bridge.WinAPI;

import Vite.Extension;
import Vite.Type.Object;

///
/// @brief Bridge: Windows API
/// @todo Further research on how to reduce the export.
///

#pragma warning(push, 0)
export {


namespace WinAPI {
    ///
    /// Data
    ///
    
    // Constants
    constexpr auto gEnumerateCurrentSettings = ENUM_CURRENT_SETTINGS;
    constexpr auto gEnumerateRegistrySettings = ENUM_REGISTRY_SETTINGS;

    // Enumerations
    enum DisplayDeviceState: unsigned long {
        Active = DISPLAY_DEVICE_ACTIVE,
        Attached = DISPLAY_DEVICE_ATTACHED_TO_DESKTOP,
        Primary = DISPLAY_DEVICE_PRIMARY_DEVICE,
        Remote = DISPLAY_DEVICE_REMOTE,
    };
    
    enum SystemMetrics: int {
        ScreenCount = SM_CMONITORS,         // Number of display monitors on the desktop.
        ScreenX = SM_CXSCREEN,              // Width of the current screen, in pixels.
        ScreenY = SM_CYSCREEN,              // Height of the current screen, in pixels.
        SystemShutdown = SM_SHUTTINGDOWN,   // The system is being shut down.
        WindowBorderX = SM_CXBORDER,        // Width of the current window border, in pixels.
        WindowBorderY = SM_CYBORDER,        // Height of the current window border, in pixels.
        WindowFrameSizeX = SM_CXSIZEFRAME,  // Width of the current window frame, in pixels.
        WindowFrameSizeY = SM_CYSIZEFRAME,  // Height of the current window frame, in pixels.
    };

    // Handles
    using DeviceContextHandle = ::HDC;
    using GenericHandle = ::HANDLE;
    using IconHandle = ::HICON;
    using ModuleHandle = ::HMODULE; // Includes also HINSTANCE.
    using WindowHandle = ::HWND;

    // Types
    using ::LPARAM;
    using ::LRESULT;
    using ::UINT;
    using ::WPARAM;

    // Structures
    using DeviceMode = ::DEVMODE;
    using DisplayDevice = ::DISPLAY_DEVICE;
    using Message = ::MSG;
    using MonitorInfoExtended = ::MONITORINFOEX;
    using Point = ::POINT;
    using RawInputDevice = ::RAWINPUTDEVICE;
    using TaskbarList = ::ITaskbarList3;

    ///
    /// Functions
    ///

    // Display
    #undef EnumDisplayDevices
    [[nodiscard]] inline auto EnumDisplayDevices(LPCWSTR lpDevice, DWORD iDevEnum, DISPLAY_DEVICE *lpDisplayDevice, DWORD dwFlags) noexcept {
        return ::EnumDisplayDevicesW(lpDevice, iDevEnum, lpDisplayDevice, dwFlags);
    }

    [[nodiscard]] inline auto EnumDisplayMonitors(HDC hdc, LPRECT lprcClip, MONITORENUMPROC lpfnEnum, LPARAM dwData) {
        return ::EnumDisplayMonitors(hdc, lprcClip, lpfnEnum, dwData);
    }

    #undef EnumDisplaySettings
    [[nodiscard]] inline auto EnumDisplaySettings(LPCWSTR deviceName, DWORD iModeNum, DEVMODE *lpDevMode) noexcept {
        return ::EnumDisplaySettingsW(deviceName, iModeNum, lpDevMode);
    }

    #undef GetMonitorInfo
    [[nodiscard]] inline auto GetMonitorInfo(HMONITOR hMonitor, MONITORINFOEX *lpmi) noexcept {
        return ::GetMonitorInfoW(hMonitor, lpmi);
    }

    // Icon
    #undef LoadIcon
    [[nodiscard]] inline auto LoadIcon(HINSTANCE hInstance, LPCSTR lpIconName) noexcept {
        return ::LoadIconA(hInstance, lpIconName);
    }

    [[nodiscard]] inline auto LoadIcon(HINSTANCE hInstance, LPCWSTR lpIconName) noexcept {
        return ::LoadIconW(hInstance, lpIconName);
    }

    // Library
    #undef LoadLibrary
    [[nodiscard]] inline auto LoadLibrary(LPCSTR lpLibFileName) noexcept {
        return ::LoadLibraryA(lpLibFileName);
    }

    [[nodiscard]] inline auto LoadLibrary(LPCWSTR lpLibFileName) noexcept {
        return ::LoadLibraryW(lpLibFileName);
    }

    #undef GetModuleHandle
    [[nodiscard]] inline auto GetModuleHandle(LPCSTR lpModuleName) noexcept {
        return ::GetModuleHandleA(lpModuleName);
    }

    [[nodiscard]] inline auto GetModuleHandle(LPCWSTR lpModuleName) noexcept {
        return ::GetModuleHandleW(lpModuleName);
    }

    // System
    class System: public Hedron::StaticObject {
    public:
        // Get specified system metrics.
        [[nodiscard]] static inline auto GetMetrics(SystemMetrics index) noexcept {
            return ::GetSystemMetrics(index);
        }
    };

    // Window
    class Window: public Hedron::StaticObject {
    public:
        /// Common
        // Get the active window.
        [[nodiscard]] static inline auto ActiveWindow(WindowHandle handle) noexcept {
            return ::GetActiveWindow();
        }
        // Get the focused window.
        [[nodiscard]] static inline auto FocusedWindow(WindowHandle handle) noexcept {
            return ::GetFocus();
        }
        // Get the foreground window.
        [[nodiscard]] static inline auto ForegroundWindow(WindowHandle handle) noexcept {
            return ::GetForegroundWindow();
        }

        /// Accessors
        // Get the ancestor window.
        [[nodiscard]] static inline auto GetAncestor(WindowHandle handle, unsigned int flags) noexcept {
            return ::GetAncestor(handle, flags);
        }
        // Get a related window, by command.
        [[nodiscard]] static inline auto GetRelated(WindowHandle handle, unsigned int command) noexcept {
            return ::GetWindow(handle, command);
        }
        // Get the parent window.
        [[nodiscard]] static inline auto GetParent(WindowHandle handle) noexcept {
            return ::GetParent(handle);
        }

        /// States
        // Check if the current window is active.
        [[nodiscard]] static inline auto Active(WindowHandle handle) noexcept {
            return handle ? handle == ::GetActiveWindow() : false;
        }
        // Check if the current window is focused.
        [[nodiscard]] static inline auto Focused(WindowHandle handle) noexcept {
            return handle ? handle == ::GetFocus() : false;
        }
        // Check if the current window is in the foreground.
        [[nodiscard]] static inline auto Foreground(WindowHandle handle) noexcept {
            return handle ? handle == ::GetForegroundWindow() : false;
        }
    };
}

}

#pragma warning(pop)
