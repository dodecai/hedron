﻿module;

#include <glad/gl.h>

module Vite.Platform.GLRenderDevice;

namespace Hedron {

///
/// Helpers
///
static void GLMessage(GLenum source, GLenum type, GLuint id, GLenum severity, GLsizei length, const GLchar *message, const void *userParam) {
    auto &&stacktrace = ((std::stacktrace *)userParam)->current();
    string line {};
    if (stacktrace.size() >= 2) {
        auto lastInternalEntry = std::ranges::find_if(stacktrace | std::views::drop(1), [](const auto &entry) {
            auto &&view = entry.description();
            return view.find("Hedron") != string_view::npos;
        });

        if (lastInternalEntry != stacktrace.end()) {
            line = std::format("{}[Line: {}]", lastInternalEntry->source_file(), lastInternalEntry->source_line());
        } else {
            line = "StackTrace: There are no internal entries!";
        }
    } else {
        line = "StackTrace: Empty!";
    }

    switch (severity) {
        case GL_DEBUG_SEVERITY_HIGH:
            LogError("Platform::OpenGL: {}\n  @{}", message, line);
            break;
        case GL_DEBUG_SEVERITY_MEDIUM:
            LogWarning("Platform::OpenGL: {}\n  @{}", message, line);
            break;
        case GL_DEBUG_SEVERITY_LOW:
            LogInfo("Platform::OpenGL: {}\n  @{}", message, line);
            break;
        case GL_DEBUG_SEVERITY_NOTIFICATION:
            //LogTrace("Platform::OpenGL: {}\n  @{}", message, line);
            break;
        case GL_DONT_CARE:
            Log("Platform::OpenGL: {}\n  @{}", message, line);
            break;
    }
}


///
/// Default
///
GLRenderDevice::GLRenderDevice() {
    uint32_t vao;
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);

    // Debugging-Support
    std::stacktrace trace;
    glDebugMessageCallback(GLMessage, &trace);
    //glDebugMessageCallback(GLMessage, nullptr);
    glEnable(GL_DEBUG_OUTPUT);
    glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS);

    // 3D-Support
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);   // Interprets a smaller value as "closer"

    // Anti-Aliasing Support
    glEnable(GL_TEXTURE_CUBE_MAP_SEAMLESS);
    glHint(GL_LINE_SMOOTH_HINT, GL_FASTEST);
    glHint(GL_POLYGON_SMOOTH_HINT, GL_FASTEST);

    // Clipping-Support (triangles drawn anti-clock-wize are the front face)
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CW);

    // Color-Mixing and Transparency-Support
    glEnable(GL_BLEND);
    glBlendEquation(GL_FUNC_ADD);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Switch Depth-Buffer Coordinate System (makes it easier to support DirectX and Vulkan)
    //glDepthRange(0.0f, 1.0f);

    // Program Extensions
    glEnable(GL_PROGRAM_POINT_SIZE);

    // Pixel Byte Pack/Unpack-Alignment
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    // Multisampling-Support
    glEnable(GL_MULTISAMPLE);

    // Stencil Support
    glEnable(GL_STENCIL_TEST);
    glStencilMask(0xFF);

    // Information
    auto &properties = RenderDevice::Properties();
    properties.Vendor = (const char *)glGetString(GL_VENDOR);
    properties.Model = (const char *)glGetString(GL_RENDERER);
    properties.Version = (const char *)glGetString(GL_VERSION);
    properties.SLVersion = (const char *)glGetString(GL_SHADING_LANGUAGE_VERSION);

    // ToDo: Crawl for more information
    int nrAttributes {};
    glGetIntegerv(GL_MAX_VERTEX_ATTRIBS, &nrAttributes);

    int extensionCount = 0;
    glGetIntegerv(GL_NUM_EXTENSIONS, &extensionCount);
    properties.Extensions.reserve(extensionCount);
    for (int i = 0; i < extensionCount; i++) {
        properties.Extensions.push_back((const char *)glGetStringi(GL_EXTENSIONS, i));
    }

    // Limits
    glGetIntegerv(GL_MAX_SAMPLES, &properties.MaxSamples);
    glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY, &properties.MaxAnisotropy);
    glGetIntegerv(GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS, &properties.MaxTextureUnits);

    // Uniform Block Size
    GLint maxUniformBlockSize;
    glGetIntegerv(GL_MAX_UNIFORM_BLOCK_SIZE, &maxUniformBlockSize);
    LogTrace("Max uniform block size: {}", maxUniformBlockSize);

    // Uniform Block Size
    GLint maxUniformBindings;
    glGetIntegerv(GL_MAX_UNIFORM_BUFFER_BINDINGS, &maxUniformBindings);
    LogTrace("Max uniform bindings: {}", maxUniformBindings);

    glBindVertexArray(0);
    properties.Log();
}

GLRenderDevice::~GLRenderDevice() {}


///
/// Accessors
///
void GLRenderDevice::DrawingMode(PolygonMode mode) {
    switch (mode) {
        case PolygonMode::Solid:        { glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);    break; }
        case PolygonMode::Vertices:     { glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);   break; }
        case PolygonMode::Wireframe:    { glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);    break; }
        default: {
            AppAssert(false, "The specified polygon mode isn't implemented yet!");
            break;
        }
    }
}


///
/// Commands
///
void GLRenderDevice::Capture() {
}

void GLRenderDevice::Present() {
    
}

}
